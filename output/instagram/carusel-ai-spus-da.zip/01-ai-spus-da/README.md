# Un moment pentru tine — Ai spus «da»

Carusel de patru imagini, în ordinea numerelor din numele fișierelor. Generat cu instrumentul integrat image_gen, după skill-ul stefan-dragan-design. Prompturile integrale sunt în prompts.json.

## Structură pentru următoarele postări

1. **Recunoaștere:** o propoziție care surprinde o experiență comună. Fundal albastru, titlu serif mare, accent italic.
2. **Moment concret:** o replică și o scenă cotidiană. Fundal crem, text albastru, obiecte desenate simplu.
3. **Explorare:** o întrebare despre gândurile care apar, cu exemple prezentate ca posibilități. Fundal albastru.
4. **Reflecție:** o formulare posibilă și o întrebare legată de experiența proprie. Fundal ambră/cupru, două fotolii desenate discret.

Păstrează antetul «UN MOMENT PENTRU TINE», semnătura și contul de Instagram. Adaptează situațiile fără a atribui diagnostice sau cauze certe cititorului.

## Texte

### 1
Ai spus «da».
Dar ai fi vrut
să spui «nu».

Ți s-a întâmplat și ție?

### 2
«Sigur, mă ocup eu.»

Trimiți mesajul.
Apoi te uiți la ziua deja plină
și te întrebi unde mai încape
și asta.

### 3
Ce gând a venit
înainte de «da»?

«O să se supere.»
«O să par egoist.»
«Mai bine nu complic lucrurile.»

Care dintre ele îți sună cunoscut?

### 4
Cum ar suna
un răspuns care
îți face loc și ție?

«Îți răspund după ce văd
ce pot prelua.»

Gândește-te la o situație recentă.
Ce ai fi vrut să spui?

## Descriere propusă pentru Instagram

Ai trimis un «sigur» și abia apoi te-ai întrebat când mai ai timp și pentru asta?

Poate ai vrut să ajuți. Poate ți-a trecut prin minte că un refuz ar supăra. Sau poate ai răspuns înainte să verifici ce poți prelua.

Gândește-te la o situație recentă: ce ai spus și ce ai fi vrut să spui? Poți păstra răspunsul pentru tine.

## Texte alternative

1. Pe un fundal albastru cu umbre difuze, textul «Ai spus da. Dar ai fi vrut să spui nu» și întrebarea «Ți s-a întâmplat și ție?». Un fotoliu și o lampă sunt desenate cu linii crem.
2. Pe fundal crem, replica «Sigur, mă ocup eu», urmată de scena unui mesaj trimis într-o zi deja plină. În partea de jos, o masă cu un caiet, un telefon și o cană, desenate în albastru.
3. Pe fundal albastru, întrebarea «Ce gând a venit înainte de da?», urmată de trei exemple: «O să se supere», «O să par egoist», «Mai bine nu complic lucrurile». Încheiere: «Care dintre ele îți sună cunoscut?».
4. Pe fundal ambră și cupru, întrebarea «Cum ar suna un răspuns care îți face loc și ție?», exemplul «Îți răspund după ce văd ce pot prelua» și invitația de a reflecta la o situație recentă. Două fotolii și o masă sunt desenate cu linii crem.
