# Plan de webinar pentru Ștefan Drăgan

Pregătit la 16 noiembrie 2026. Propunere de lucru pentru un eveniment pilot, urmat de o posibilă serie. Datele, bugetul, parteneriatul și calendarul se stabilesc împreună cu Ștefan și partenerul.

## Recomandarea

Primul webinar să fie **Când alcoolul devine răspunsul la stres**. Subtitlu pentru promovare: **Cum observi tiparul și când merită să ceri sprijin**.

Propun un eveniment educativ gratuit de 65 de minute, în limba română, pentru adulți, cu Ștefan ca prezentator și un moderator. Publicul principal este format din persoane care folosesc alcoolul pentru a se deconecta și încep să se întrebe dacă acest obicei le afectează viața. Aparținătorii pot participa, dar nu construim primul eveniment în jurul responsabilității lor de a schimba pe cineva.

Tema valorifică experiența în adicții descrisă în materialele existente ale lui Ștefan și continuă caruselul „Beau doar ca să mă relaxez”. Este mai ușor de explicat și promovat decât o introducere generală în toate dependențele. Experiența clinică exactă, titulatura și limitele intervenției vor fi revizuite de Ștefan înainte de publicare; nu adăugăm ani de practică, instituții sau certificări neconfirmate.

Scopul pilotului este să testeze interesul pentru tema adicțiilor, să ofere publicului o explicație utilă și să deschidă o relație cu o comunitate parteneră. Programările individuale sunt o opțiune ulterioară, nu criteriul principal al serii.

## Publicul și mesajul

**Public principal:** adulți de peste 18 ani care se regăsesc în replici precum „beau doar seara”, „am nevoie să mă relaxez” sau „îmi fac treaba, deci nu cred că e o problemă”. Pentru promovare, putem testa inițial segmentul 25–45 de ani; acesta este o ipoteză de comunicare, nu o limită clinică sau o concluzie din date despre audiență.

**Public secundar:** parteneri și prieteni care vor să înțeleagă consumul fără etichete și confruntări. Întrebările lor au loc la final; un eveniment ulterior le poate fi dedicat.

**Ce va primi participantul:** o explicație simplă a relației dintre stres și consum, trei semne care merită discutate cu un specialist și o fișă privată pentru a pregăti o conversație despre sprijin.

**Ce nu promitem:** diagnostic, tratament în grup, abstinență după o oră, o metodă de detoxificare sau o soluție identică pentru toți. Nu includem adolescenți în acest pilot; un eveniment pentru ei ar avea nevoie de alt cadru și alt limbaj.

## Temele posibile și ordinea lor

| Prioritate | Tema | Public țintă | Întrebarea de intrare | Rol în dezvoltare |
| --- | --- | --- | --- | --- |
| 1 | Când alcoolul devine răspunsul la stres | Adulți care își pun întrebări despre consum | „Mă relaxez sau am început să mă bazez pe alcool?” | Pilot pentru public și temă principală de poziționare |
| 2 | Cum vorbești cu cineva drag despre consum | Parteneri, prieteni și membri ai familiei | „Cum deschid discuția fără să o transform într-o ceartă?” | Continuare pentru aparținători, cu exemple de conversație |
| 3 | Impulsul de a consuma și situațiile care îl declanșează | Adulți care vor să înțeleagă un tipar repetitiv | „De ce apare dorința tocmai în anumite seri sau contexte?” | Atelier educativ, cu accent pe observare și sprijin |
| 4 | Jocurile de noroc când încercarea de a recupera pierderea te ține în joc | Adulți și aparținători preocupați de pariuri | „De ce e atât de greu să mă opresc după o pierdere?” | Temă separată, după validarea competenței și documentare specifică |
| 5 | Cum deschidem conversația despre consum în cabinet | Terapeuți și comunități profesionale | „Cum întreb fără să moralizez și când orientez mai departe?” | Schimb profesional separat, fără credite sau supervizare promise |

Primele trei teme pot forma o serie. Tema jocurilor de noroc nu este tratată ca o simplă extensie a alcoolului; are nevoie de propriile surse, exemple și resurse de orientare. Pentru evenimentul profesional, Ștefan și comunitatea stabilesc dacă formatul este o prezentare de experiență sau dacă este necesar un co-prezentator cu altă expertiză.

## Obiectivele pilotului

La final, participantul ar trebui să poată descrie cu propriile cuvinte un tipar de consum, să recunoască semne care justifică o evaluare și să identifice unde poate începe o discuție despre ajutor. Acestea sunt rezultate educaționale urmărite, nu promisiuni de schimbare clinică.

Explicația centrală este că ușurarea temporară poate încuraja repetarea consumului, iar folosirea alcoolului pentru a face față stresului poate întreține dificultățile în timp. Modelul prezentat este simplificat și nu explică toate cauzele adicției. [NIAAA despre ciclul adicției](https://www.niaaa.nih.gov/publications/cycle-alcohol-addiction).

Semnele discutate vor fi consumul peste intenție, dificultatea de a reduce și continuarea în ciuda consecințelor. Ele oferă motive pentru o evaluare, nu un diagnostic obținut dintr-un sondaj. [NIAAA despre tulburarea de consum de alcool](https://www.niaaa.nih.gov/publications/brochures-and-fact-sheets/understanding-alcohol-use-disorder).

## Desfășurarea celor 65 de minute

| Minute | Conținut | Participare și suport |
| --- | --- | --- |
| 0–5 | Prezentare, ce acoperim, regulile întâlnirii | Cameră și microfon opționale; explicăm canalul de întrebări |
| 5–12 | O seară obișnuită după o zi grea | Vinietă fictivă și sondaj despre ce vrea publicul să înțeleagă |
| 12–22 | Ce poate menține tiparul | Hartă simplă a contextului, a efectului imediat și a consecințelor ulterioare |
| 22–32 | Cum observăm problema dincolo de etichete | Trei semne relevante; de ce faptul că funcționezi la muncă nu încheie discuția |
| 32–40 | Exercițiu privat de observare | Fișa participantului; se poate folosi cazul fictiv, fără experiențe personale |
| 40–48 | Cum arată primul pas către sprijin | Diferența dintre conversație psihologică, evaluare și ajutor medical |
| 48–50 | Recapitulare și resurse | Un singur link către fișă și resurse; solicitarea unei discuții rămâne opțională |
| 50–65 | Întrebări și răspunsuri | Moderatorul grupează întrebările; fără evaluări individuale publice |

Păstrăm maximum 12 slide-uri. Ghidul din `02-ghid-prezentator.md` leagă fiecare slide de minutele și formulările propuse. Este o bază de repetiție; Ștefan își adaptează vocea și aprobă conținutul clinic.

## Cadrul de participare

Recomandarea pentru pilot este fără înregistrarea participanților sau a întrebărilor. Pentru conținut ulterior, Ștefan poate filma separat o sinteză. Nu promitem anonimat complet: numele afișat și alte date pot fi vizibile, în funcție de platformă. Dacă dorim întrebări fără nume, testăm un formular care nu solicită autentificare sau date de identificare și explicăm limitele lui.

Moderatorul le cere oamenilor să nu publice nume sau istorii identificabile. El poate opri o relatare detaliată cu „Îți mulțumesc că ai adus întrebarea. O voi reformula general, ca să îți protejăm intimitatea”. Participanții nu sunt invitați să posteze cantități consumate, diagnostice ori episoade de sevraj în chat.

Pentru consum cu posibilă dependență fizică, nu propunem un experiment de oprire bruscă. Sevrajul poate necesita îngrijire medicală; această distincție este explicată în segmentul despre sprijin. Dacă apar relatări despre convulsii, confuzie sau halucinații în contextul opririi consumului, răspunsul este orientarea către ajutor medical urgent, nu o intervenție în webinar. [NHS despre consum și sevraj](https://www.nhs.uk/conditions/alcohol-use-disorder/).

## Materiale și responsabilități

**Ștefan:** validează tema, bio-ul, sursele și răspunsurile la întrebări; adaptează prezentarea; stabilește în ce situații trimite către medic sau alte servicii. Folosește exemple fictive, nu cazuri recognoscibile din clinică.

**Alex:** coordonează calendarul, pregătește slide-urile și comunicarea în stilul existent, verifică linkurile și organizează repetiția tehnică. Livrează un raport scurt după eveniment.

**Moderatorul:** deschide sala, gestionează întrebările, urmărește timpul și evită expunerea de informații personale. La pilot poate fi desemnat de partener sau poate fi Alex, după o pregătire cu Ștefan.

**Partenerul:** contribuțiile privind sala virtuală, formularul, promovarea și mesajele de acces se confirmă în scris. Nu presupunem acces la baza sa de date sau la infrastructură înainte de acord.

Materialele necesare lansării sunt 12 slide-uri, fișa participantului, o pagină de înscriere, o confirmare cu invitație de calendar, două remindere, un formular de feedback și o listă verificată de resurse. Nu sunt necesare o platformă nouă, reclame plătite sau un webinar înregistrat pentru primul test.

## Promovare pe trei săptămâni

Folosim ziua evenimentului ca reper T. Nu publicăm data înainte ca prezentatorul și partenerul să confirme disponibilitatea.

| Moment | Acțiune | Responsabil propus |
| --- | --- | --- |
| T minus 21–18 zile | Confirmăm tema, partenerul, rolurile și destinația unică a înscrierilor | Alex și Ștefan, apoi partenerul |
| T minus 17 zile | Pagină și formular testate; bio și text aprobate | Alex și organizatorul |
| T minus 14 zile | Anunț comun și distribuire către comunitățile proprii | Fiecare pe canalele sale |
| T minus 10 zile | Caruselul despre alcool și stres, cu legătură spre webinar | Ștefan și partenerul, dacă acceptă |
| T minus 7 zile | Video de 30–45 secunde cu Ștefan și o întrebare din eveniment | Ștefan, editare Alex |
| T minus 3 zile | Story cu o întrebare generală și invitație de înscriere | Fiecare organizator |
| T minus 1 zi | Reminder cu ora României și linkul de acces | Organizatorul înscrierilor |
| T minus 1 oră | Reminder scurt, fără presiune | Organizatorul înscrierilor |
| T plus 1 zi | Fișa, resursele și feedbackul promis | Organizatorul înscrierilor |
| T plus 7 zile | Raport și decizie privind următoarea temă | Alex și Ștefan cu partenerul |

Nu deducem că persoanele care au interacționat cu un carusel au o adicție. Formulările de promovare vor invita la înțelegere, fără a eticheta publicul.

### Text pentru pagina de înscriere

**Când alcoolul devine răspunsul la stres**

„Beau doar ca să mă relaxez.” Ce merită observat când această replică începe să se repete? Într-o întâlnire online cu Ștefan Drăgan, vorbim despre rolul consumului, semnele care merită discutate cu un specialist și primul pas către sprijin.

Pentru adulți care își pun întrebări despre propriul consum sau vor să înțeleagă mai bine experiența unei persoane apropiate. Participi în ritmul tău, fără obligația de a povesti experiențe personale. Include un exercițiu privat și întrebări la final.

Format propus: gratuit, online, 65 de minute. Data și ora se adaugă după confirmare. Întâlnire educativă; nu oferă diagnostic sau tratament individual.

Buton recomandat: **Primește linkul de participare**.

## Înscriere și continuarea relației

Recomandăm email și confirmarea eligibilității 18+, cu prenume opțional. Nu cerem istoric de consum, diagnostic, număr de telefon sau angajator. O întrebare opțională poate fi „Ce subiect ai vrea să înțelegi mai bine?”, cu variante generale. Organizatorul verifică informarea privind folosirea datelor și configurează separat orice abonare la marketing. Nu tratăm înscrierea la eveniment ca înscriere automată la un newsletter.

La final, îndemnul principal este folosirea fișei și consultarea resurselor. Un link separat poate oferi o discuție individuală persoanelor interesate. Destinația sa și formularea gratuității se stabilesc cu partenerul: prima ședință gratuită oferită de Ștefan nu se prezintă ca regulă a Mindtale sau a tuturor terapeuților. Nu contactăm individual participanții pe baza unor presupuneri despre consumul lor.

## Efort și buget pentru pilot

Estimări de planificare, nu tarife de piață sau cheltuieli aprobate: aproximativ 7–10 ore pentru Ștefan, incluzând validare, adaptare, repetiție și livrare; 10–14 ore pentru Alex, incluzând materiale, pagină, coordonare și raport; 2–3 ore pentru moderator. Nu cumulăm orele moderatorului cu ale lui Alex dacă aceeași persoană îndeplinește ambele roluri.

Propunerea inițială este promovare organică și fără cumpărarea unui instrument nou. Costul sălii virtuale se verifică în contul organizatorului. Onorariul prezentatorului, serviciile de producție și orice contribuție a partenerului se stabilesc înainte de lansare. Un eveniment gratuit pentru public nu presupune muncă gratuită acceptată automat de colaboratori.

## Cum evaluăm pilotul

Ținte interne de test, nu prognoze: 50 de înscrieri, cel puțin 20 de participanți unici live și 10 răspunsuri la feedback. Cu acest exemplu, rata de participare este 20 împărțit la 50, adică 40%. Prezența până la minutul 50 se urmărește numai dacă instrumentul oferă date agregate fiabile.

În feedback întrebăm: „Cât de clar a fost conținutul?” pe o scară 1–5, „Poți numi un pas prin care ai cere sprijin?” cu răspuns opțional și „Ce temă ai vrea în continuare?”. O medie de 4/5 la claritate este o țintă de îmbunătățire, nu o măsură de eficiență terapeutică.

Urmărim și sursa înscrierii prin linkuri distincte, fără etichete clinice în URL. Comparăm numărul de înscrieri pe canal; fără date despre expunere, nu numim această comparație rată de conversie. Solicitările voluntare de programare pot fi numărate agregat, separat de identitatea participanților în raportul comun.

Dacă interesul este mic, cerem feedback și schimbăm titlul sau canalul înainte de a extinde seria. Dacă apar multe întrebări de tratament individual ori de urgență, restrângem promisiunea și consolidăm moderarea. O a doua ediție are sens dacă publicul găsește tema utilă, Ștefan se simte confortabil în format și partenerul confirmă că poate susține repetarea lui.

## Deciziile de închis înainte de anunț

Ștefan confirmă tema și bio-ul; organizatorii stabilesc data, moderatorul, bugetul, sala și responsabilul înscrierilor. Apoi aprobă împreună pagina, destinația resurselor, regula de înregistrare și eventuala opțiune de programare. Planul poate fi folosit imediat pentru discuția cu partenerul, fără a publica încă un eveniment sau a promite locuri.
